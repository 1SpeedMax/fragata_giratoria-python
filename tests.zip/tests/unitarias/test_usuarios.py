from django.test import TestCase
from usuarios.models import Rol, Usuario


class UsuarioModelTest(TestCase):

    def setUp(self):
        self.rol = Rol.objects.create(
            nombre_rol="ADMIN"
        )

    def test_crear_rol(self):
        self.assertEqual(self.rol.nombre_rol, "ADMIN")

    def test_crear_usuario(self):

        usuario = Usuario.objects.create_user(
            email="admin@test.com",
            password="123456",
            nombre_usuario="admin",
            rol=self.rol
        )

        self.assertEqual(
            usuario.email,
            "admin@test.com"
        )

    def test_password_correcta(self):

        usuario = Usuario.objects.create_user(
            email="admin@test.com",
            password="123456",
            nombre_usuario="admin"
        )

        self.assertTrue(
            usuario.check_password("123456")
        )

    def test_estado_por_defecto(self):

        usuario = Usuario.objects.create_user(
            email="admin@test.com",
            password="123456",
            nombre_usuario="admin"
        )

        self.assertEqual(
            usuario.estado,
            "ACTIVO"
        )