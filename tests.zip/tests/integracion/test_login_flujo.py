from django.test import TestCase
from usuarios.models import Usuario


class LoginIntegracionTest(TestCase):

    def setUp(self):

        Usuario.objects.create_user(
            email="admin@test.com",
            password="123456",
            nombre_usuario="admin"
        )

    def test_login_usuario(self):

        login = self.client.login(
            email="admin@test.com",
            password="123456"
        )

        self.assertTrue(login)